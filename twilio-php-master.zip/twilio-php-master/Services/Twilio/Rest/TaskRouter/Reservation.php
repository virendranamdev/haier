<?php

class Services_Twilio_Rest_TaskRouter_Reservation extends Services_Twilio_TaskRouterInstanceResource {

}
