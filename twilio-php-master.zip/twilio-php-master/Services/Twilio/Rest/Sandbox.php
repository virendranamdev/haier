<?php

class Services_Twilio_Rest_Sandbox
    extends Services_Twilio_InstanceResource
{
}
